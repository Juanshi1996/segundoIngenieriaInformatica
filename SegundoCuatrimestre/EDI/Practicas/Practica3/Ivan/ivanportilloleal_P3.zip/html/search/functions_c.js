var searchData=
[
  ['nombre',['nombre',['../classedi_1_1_persona.html#a1bcda68b6cb96169c54d83395dd6b4a3',1,'edi::Persona::nombre() const '],['../classedi_1_1_persona.html#a4db93f1e2f8c6d5a08f5fb9fc00a1972',1,'edi::Persona::nombre(const std::string &amp;nombre)']]]
];
