var searchData=
[
  ['head_5f',['head_',['../classds_1_1_doubly_linked_sorted_list.html#ac5517baaf0faaf763506fe45c2af249a',1,'ds::DoublyLinkedSortedList']]]
];
