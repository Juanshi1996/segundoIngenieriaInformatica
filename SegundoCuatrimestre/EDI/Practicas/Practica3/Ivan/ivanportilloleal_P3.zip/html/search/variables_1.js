var searchData=
[
  ['current_5f',['current_',['../classds_1_1_doubly_linked_sorted_list.html#a08fcad9b923e0136c32d52c49ebcd0a4',1,'ds::DoublyLinkedSortedList']]]
];
