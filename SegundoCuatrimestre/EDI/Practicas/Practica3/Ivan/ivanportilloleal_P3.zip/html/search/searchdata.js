var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprsuwy~",
  1: "bcdklnops",
  2: "de",
  3: "dfgkmnps",
  4: "abcdefghiklmnoprsu~",
  5: "_cdhnp",
  6: "abgilmoprswy",
  7: "be"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "defines",
  7: "groups"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Namespaces",
  3: "Archivos",
  4: "Funciones",
  5: "Variables",
  6: "&apos;defines&apos;",
  7: "Grupos"
};

