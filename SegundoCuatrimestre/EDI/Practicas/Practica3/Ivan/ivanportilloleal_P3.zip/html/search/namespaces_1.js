var searchData=
[
  ['edi',['edi',['../namespaceedi.html',1,'']]]
];
