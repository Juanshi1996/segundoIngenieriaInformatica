var searchData=
[
  ['next_5f',['next_',['../classds_1_1_node.html#a99c78bbc7b8ce45bd5ecc863bffe1d92',1,'ds::Node']]],
  ['node',['Node',['../classds_1_1_node.html',1,'ds']]],
  ['node_2ehpp',['node.hpp',['../node_8hpp.html',1,'']]],
  ['node_3c_20edi_3a_3apersona_20_3e',['Node&lt; edi::Persona &gt;',['../classds_1_1_node.html',1,'ds']]],
  ['nombre',['nombre',['../classedi_1_1_persona.html#a1bcda68b6cb96169c54d83395dd6b4a3',1,'edi::Persona::nombre() const '],['../classedi_1_1_persona.html#a4db93f1e2f8c6d5a08f5fb9fc00a1972',1,'edi::Persona::nombre(const std::string &amp;nombre)']]]
];
