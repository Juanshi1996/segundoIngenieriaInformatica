var searchData=
[
  ['next_5f',['next_',['../classds_1_1_node.html#a99c78bbc7b8ce45bd5ecc863bffe1d92',1,'ds::Node']]]
];
