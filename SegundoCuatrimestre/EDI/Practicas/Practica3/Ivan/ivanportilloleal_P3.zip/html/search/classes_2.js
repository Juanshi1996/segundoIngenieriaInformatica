var searchData=
[
  ['doublylinkedsortedlist',['DoublyLinkedSortedList',['../classds_1_1_doubly_linked_sorted_list.html',1,'ds']]],
  ['doublylinkedsortedlist_3c_20edi_3a_3apersona_20_3e',['DoublyLinkedSortedList&lt; edi::Persona &gt;',['../classds_1_1_doubly_linked_sorted_list.html',1,'ds']]]
];
