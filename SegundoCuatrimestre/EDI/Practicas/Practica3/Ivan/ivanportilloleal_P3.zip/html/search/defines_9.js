var searchData=
[
  ['subrayado',['SUBRAYADO',['../macros_8hpp.html#a3ab8b4157fd29a2336c702b26a967bb9',1,'macros.hpp']]]
];
