var searchData=
[
  ['node',['Node',['../classds_1_1_node.html',1,'ds']]],
  ['node_3c_20edi_3a_3apersona_20_3e',['Node&lt; edi::Persona &gt;',['../classds_1_1_node.html',1,'ds']]]
];
