var searchData=
[
  ['persona',['Persona',['../classedi_1_1_persona.html#adf50e6e02e0d82db7037f74a6cbd7650',1,'edi::Persona::Persona()'],['../classedi_1_1_persona.html#a9c4eb473b73ccdb33406011032cdaef9',1,'edi::Persona::Persona(const std::string &amp;n, const std::string &amp;a, const int &amp;d)'],['../classedi_1_1_persona.html#aa73785a179a7230fba804826bff5ab62',1,'edi::Persona::Persona(const Persona &amp;p)']]],
  ['postorderbinarytreeprocessor',['postorderBinaryTreeProcessor',['../group___b_t_utils.html#ga4aeb75053283685b778f6253be052d58',1,'edi']]],
  ['preorderbinarytreeprocessor',['preorderBinaryTreeProcessor',['../group___b_t_utils.html#ga494bc0e28f04620e0f47a386a4bf4415',1,'edi']]]
];
