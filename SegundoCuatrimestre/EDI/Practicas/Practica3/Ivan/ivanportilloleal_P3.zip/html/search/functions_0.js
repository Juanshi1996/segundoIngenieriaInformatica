var searchData=
[
  ['apellido',['apellido',['../classedi_1_1_persona.html#aebb7317d5f61ab5c3fa7e9cdf237880c',1,'edi::Persona::apellido() const '],['../classedi_1_1_persona.html#a1b709f2be9753e4cc10215d12e716a16',1,'edi::Persona::apellido(const std::string &amp;apellido)']]]
];
