var searchData=
[
  ['key',['Key',['../classds_1_1_key.html#a5fb8077d20d89e090f6d6b2d636452a7',1,'ds::Key::Key()'],['../classds_1_1_key.html#aed433af8f70321b338086b70e1067c46',1,'ds::Key::Key(int dni, int position)'],['../classds_1_1_key.html#a4ec57c17cd77e157c4210ea9b89566d9',1,'ds::Key::Key(const Key &amp;key)']]]
];
