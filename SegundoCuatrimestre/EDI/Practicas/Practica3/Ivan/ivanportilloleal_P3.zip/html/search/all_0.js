var searchData=
[
  ['_5fapellido',['_apellido',['../classedi_1_1_persona.html#a7720d0dc4358f4c787e1d6031e1d3c27',1,'edi::Persona']]],
  ['_5fborrado',['_borrado',['../classedi_1_1_persona.html#ad9967efe17ccaa5db8664ed643cd4a79',1,'edi::Persona']]],
  ['_5fcurr',['_curr',['../classedi_1_1_linked_ordered_binary_tree.html#af08ca9ef20e8265fde64f1b9b517f907',1,'edi::LinkedOrderedBinaryTree']]],
  ['_5fdni',['_dni',['../classedi_1_1_persona.html#a20e547df93a43b84bd0d3f4f40c585d8',1,'edi::Persona']]],
  ['_5fnombre',['_nombre',['../classedi_1_1_persona.html#aad8a85af9918ea9d70829d36fd754313',1,'edi::Persona']]],
  ['_5fprev',['_prev',['../classedi_1_1_linked_ordered_binary_tree.html#a5ad4052d817e481c6bc4f28cb3840228',1,'edi::LinkedOrderedBinaryTree']]],
  ['_5fstudents',['_students',['../classds_1_1_subject.html#ae682d6cdb0460ee28a5e871f1d41d867',1,'ds::Subject']]]
];
