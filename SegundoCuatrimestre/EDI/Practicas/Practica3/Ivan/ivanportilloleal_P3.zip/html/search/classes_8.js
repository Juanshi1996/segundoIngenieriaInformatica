var searchData=
[
  ['sortedlist',['SortedList',['../classds_1_1_sorted_list.html',1,'ds']]],
  ['sortedlist_3c_20edi_3a_3apersona_20_3e',['SortedList&lt; edi::Persona &gt;',['../classds_1_1_sorted_list.html',1,'ds']]],
  ['subject',['Subject',['../classds_1_1_subject.html',1,'ds']]]
];
