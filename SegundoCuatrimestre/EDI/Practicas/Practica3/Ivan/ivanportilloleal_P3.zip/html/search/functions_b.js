var searchData=
[
  ['modifystudent',['modifyStudent',['../classds_1_1_subject.html#ad9a6fd0afbfce694f76042d80191384c',1,'ds::Subject']]]
];
