var searchData=
[
  ['persona',['Persona',['../classedi_1_1_persona.html',1,'edi']]]
];
