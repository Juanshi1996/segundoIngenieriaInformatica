var searchData=
[
  ['black',['BLACK',['../macros_8hpp.html#a7b3b25cba33b07c303f3060fe41887f6',1,'macros.hpp']]],
  ['blue',['BLUE',['../macros_8hpp.html#a79d10e672abb49ad63eeaa8aaef57c38',1,'macros.hpp']]],
  ['borrar',['BORRAR',['../macros_8hpp.html#a79bf316fce01e63d76dddcdcbe72ab1c',1,'macros.hpp']]]
];
