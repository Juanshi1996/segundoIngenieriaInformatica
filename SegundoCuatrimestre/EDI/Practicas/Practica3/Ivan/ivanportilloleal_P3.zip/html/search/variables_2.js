var searchData=
[
  ['data_5f',['data_',['../classds_1_1_node.html#ac1fa9aaef68ee5f8e78392fcdb9f13d4',1,'ds::Node']]],
  ['dni_5f',['DNI_',['../classds_1_1_key.html#a942bb2dff7a8a7dcb7010b98d972ffa3',1,'ds::Key']]]
];
