var searchData=
[
  ['macros_2ehpp',['macros.hpp',['../macros_8hpp.html',1,'']]],
  ['magenta',['MAGENTA',['../macros_8hpp.html#a6f699060902f800f12aaae150f3a708e',1,'macros.hpp']]],
  ['modifystudent',['modifyStudent',['../classds_1_1_subject.html#ad9a6fd0afbfce694f76042d80191384c',1,'ds::Subject']]]
];
